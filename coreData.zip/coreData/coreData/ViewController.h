//
//  ViewController.h
//  coreData
//
//  Created by SivaKoti on 23/03/17.
//  Copyright © 2017 SivaKoti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *TABLEview;

@property (strong, nonatomic) IBOutlet UIButton *addnewBtn;

@property (strong) NSMutableArray *Dataarray;

@end

