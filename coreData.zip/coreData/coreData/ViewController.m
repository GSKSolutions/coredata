//
//  ViewController.m
//  coreData
//
//  Created by SivaKoti on 23/03/17.
//  Copyright © 2017 SivaKoti. All rights reserved.
//

#import "ViewController.h"
#import "detailsCell.h"
#import "DetailsVC.h"
#import "Employe+CoreDataClass.h"
#import "AppDelegate.h"
@interface ViewController ()
{
    NSManagedObjectContext* employeContext;
}
@end

@implementation ViewController
//- (NSManagedObjectContext *)managedObjectContext
//{
//    NSManagedObjectContext *MOBJcontext = nil;
//    id delegate = [[UIApplication sharedApplication] delegate];
//    if ([delegate performSelector:@selector(managedObjectContext)]) {
//        MOBJcontext = [delegate managedObjectContext];
//    }
//    return MOBJcontext;
//}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    employeContext = ((AppDelegate*)UIApplication.sharedApplication.delegate).persistentContainer.viewContext;

    // Fetch the devices from persistent data store
    NSManagedObjectContext *managedObjectContext = employeContext;
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"Employe"];
    self.Dataarray = [[managedObjectContext executeFetchRequest:fetchRequest error:nil] mutableCopy];
    
    [self.TABLEview reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    _TABLEview.delegate=self;
    _TABLEview.dataSource=self;
    [_addnewBtn addTarget:self action:@selector(addNewDetails:) forControlEvents:UIControlEventTouchUpInside];
}
- (IBAction)addNewDetails:(id)sender {
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    DetailsVC *classObj = [storyBoard instantiateViewControllerWithIdentifier:@"DetailsVC"];
    [self.navigationController pushViewController:classObj animated:YES];
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return self.Dataarray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"detailsCell";
//    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
//    NSMutableArray *sampleArray=[[NSMutableArray alloc]init];
    detailsCell *customcell =  [_TABLEview dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (!customcell)
    {
            customcell =(detailsCell *) [[[NSBundle mainBundle] loadNibNamed:@"detailsCell" owner:self options:nil]objectAtIndex:0] ;
    }
//    customcell.name.text=@"Siva Koti";
//    customcell.email.text=@"gsk@mxc.kkd";
//    customcell.phone.text=@"999999999";
    NSManagedObject *device = [self.Dataarray objectAtIndex:indexPath.row];
    customcell.name.text =[NSString stringWithFormat:@"%@", [device valueForKey:@"name"]];
    customcell.employeId.text =[NSString stringWithFormat:@"Emp ID: %@", [device valueForKey:@"empID"]];
//    customcell.phone.text =@"";//[NSNumber numberWithInt:[[device valueForKey:@"phone"] intValue]];
    customcell.phone.text=[NSString stringWithFormat:@"%@",[device valueForKey:@"phone"]];
    customcell.email.text =[device valueForKey:@"mail"];
//    [customcell.textLabel setText:[NSString stringWithFormat:@"%@", [device valueForKey:@"name"]]];
    
    
    return customcell;
}


// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSManagedObjectContext *context = employeContext;
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete object from database
        [context deleteObject:[self.Dataarray objectAtIndex:indexPath.row]];
        
        NSError *error = nil;
        if (![context save:&error]) {
            NSLog(@"Can't Delete! %@ %@", error, [error localizedDescription]);
            return;
        }
        
        // Remove device from table view
        [self.Dataarray removeObjectAtIndex:indexPath.row];
        [self.TABLEview deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSManagedObject *selectedDevice = [self.Dataarray objectAtIndex:[[self.TABLEview indexPathForSelectedRow] row]];
    
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    DetailsVC *classObj = [storyBoard instantiateViewControllerWithIdentifier:@"DetailsVC"];
    classObj.employeDB = selectedDevice;

    [self.navigationController pushViewController:classObj animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
