//
//  DetailsVC.h
//  coreData
//
//  Created by SivaKoti on 23/03/17.
//  Copyright © 2017 SivaKoti. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Employe+CoreDataClass.h"
@interface DetailsVC : UIViewController<UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *fullname;
@property (strong, nonatomic) IBOutlet UITextField *employeID;
@property (strong, nonatomic) IBOutlet UITextField *email;
@property (strong, nonatomic) IBOutlet UITextField *phone;
@property (strong, nonatomic) IBOutlet UIButton *addEntityBtn;
@property (strong, nonatomic) IBOutlet UIButton *clearBtn;

@property (strong) NSManagedObject *employeDB;

@end
