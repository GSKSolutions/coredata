//
//  detailsCell.m
//  coreData
//
//  Created by SivaKoti on 23/03/17.
//  Copyright © 2017 SivaKoti. All rights reserved.
//

#import "detailsCell.h"

@implementation detailsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
