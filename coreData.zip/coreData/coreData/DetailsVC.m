//
//  DetailsVC.m
//  coreData
//
//  Created by SivaKoti on 23/03/17.
//  Copyright © 2017 SivaKoti. All rights reserved.
//

#import "DetailsVC.h"
#import "AppDelegate.h"
#import "ViewController.h"
@interface DetailsVC ()
{
    NSManagedObjectContext* employeContext;
}
@end

@implementation DetailsVC

- (void)viewDidLoad {
    [super viewDidLoad];
    _fullname.delegate=self;
    _email.delegate=self;
    _phone.delegate=self;
    _employeID.delegate=self;

    employeContext = ((AppDelegate*)UIApplication.sharedApplication.delegate).persistentContainer.viewContext;

    if (self.employeDB) {
        [self.fullname setText:[self.employeDB valueForKey:@"name"]];
        [self.email setText:[self.employeDB valueForKey:@"mail"]];
        [self.phone setText:[NSString stringWithFormat:@"%@",[self.employeDB valueForKey:@"phone"]]];
        [self.employeID setText:[NSString stringWithFormat:@"%d",[[self.employeDB valueForKey:@"empID"] intValue]]];

    }

    // Do any additional setup after loading the view.
    [_clearBtn addTarget:self action:@selector(clerTFdata:) forControlEvents:UIControlEventTouchUpInside];
    [_addEntityBtn addTarget:self action:@selector(saveEmployeDetails:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - button Actions

- (IBAction)saveEmployeDetails:(id)sender {
    NSManagedObjectContext *OBJcontext = employeContext;
    
    if (self.employeDB) {
        // Update existing device
        [self.employeDB setValue:self.fullname.text forKey:@"name"];
        [self.employeDB setValue:self.email.text forKey:@"mail"];
        [self.employeDB setValue:self.phone.text forKey:@"phone"];
        [self.employeDB setValue:[NSNumber numberWithInt:[self.employeID.text intValue]] forKey:@"empID"];
        
    } else {
        // Create a new device
        NSManagedObject *newDevice = [NSEntityDescription insertNewObjectForEntityForName:@"Employe" inManagedObjectContext:employeContext];
        [newDevice setValue:self.fullname.text forKey:@"name"];
        [newDevice setValue:self.email.text forKey:@"mail"];
        [newDevice setValue:self.phone.text forKey:@"phone"];
        [newDevice setValue:[NSNumber numberWithInt:[self.employeID.text intValue]] forKey:@"empID"];

        NSLog(@"new dev %@", newDevice);

    }
    NSError *error = nil;
    // Save the object to persistent store
    if (![OBJcontext save:&error]) {
        NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ViewController *classObj = [storyBoard instantiateViewControllerWithIdentifier:@"ViewController"];
    [self.navigationController pushViewController:classObj animated:YES];

}
- (IBAction)clerTFdata:(id)sender {
    _fullname.text=@"";
    _email.text=@"";
    _phone.text=@"";
    _employeID.text=@"";
}
#pragma mark - TextField Delegates
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}


@end
