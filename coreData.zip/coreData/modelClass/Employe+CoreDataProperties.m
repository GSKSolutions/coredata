//
//  Employe+CoreDataProperties.m
//  coreData
//
//  Created by SivaKoti on 28/03/17.
//  Copyright © 2017 SivaKoti. All rights reserved.
//

#import "Employe+CoreDataProperties.h"

@implementation Employe (CoreDataProperties)

+ (NSFetchRequest<Employe *> *)fetchRequest {
	return [[NSFetchRequest alloc] initWithEntityName:@"Employe"];
}

@dynamic mail;
@dynamic name;
@dynamic phone;
@dynamic empID;

@end
