//
//  Employe+CoreDataClass.h
//  coreData
//
//  Created by SivaKoti on 28/03/17.
//  Copyright © 2017 SivaKoti. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface Employe : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "Employe+CoreDataProperties.h"
