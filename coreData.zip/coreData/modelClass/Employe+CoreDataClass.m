//
//  Employe+CoreDataClass.m
//  coreData
//
//  Created by SivaKoti on 28/03/17.
//  Copyright © 2017 SivaKoti. All rights reserved.
//

#import "Employe+CoreDataClass.h"

@implementation Employe

@end
