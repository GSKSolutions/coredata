//
//  Employe+CoreDataProperties.h
//  coreData
//
//  Created by SivaKoti on 28/03/17.
//  Copyright © 2017 SivaKoti. All rights reserved.
//

#import "Employe+CoreDataClass.h"


NS_ASSUME_NONNULL_BEGIN

@interface Employe (CoreDataProperties)

+ (NSFetchRequest<Employe *> *)fetchRequest;

@property (nullable, nonatomic, copy) NSString *mail;
@property (nullable, nonatomic, copy) NSString *name;
@property (nullable, nonatomic, copy) NSString *phone;
@property (nonatomic) int32_t empID;

@end

NS_ASSUME_NONNULL_END
